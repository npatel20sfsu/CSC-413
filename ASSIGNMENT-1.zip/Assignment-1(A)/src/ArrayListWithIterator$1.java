//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package arraylistwithiterator;

// $FF: synthetic class
class ArrayListWithIterator$1 {
}
